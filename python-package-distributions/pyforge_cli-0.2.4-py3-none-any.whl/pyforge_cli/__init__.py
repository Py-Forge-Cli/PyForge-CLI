"""PyForge CLI - A powerful data format conversion and synthetic data generation tool."""

__version__ = "0.2.4"
__author__ = "Santosh Dandey"
__email__ = "dd.santosh@gmail.com"